# Apply patched UIO drivers on CentOS 8.3

```bash

# Kernel Version

▶ uname -r
4.18.0-240.10.1.el8_3.x86_64

# Checksum of UIO drivers

▶ cksum uio*
3774937999 111600 uio.ko.xz
2880221613 92588 uio_pci_generic.ko.xz

# Unload UIO drivers and mv original uio drivers

sudo modprobe -r uio_pci_generic
sudo mv /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz.orig
sudo mv /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz.orig

# Copy patched UIO drivers at driver's location

sudo cp uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz
sudo cp uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz

# Verify checksum of UIO drivers

▶ cksum /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz  /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz
3774937999 111600 /lib/modules/4.18.0-240.10.1.el8_3.x86_64/kernel/drivers/uio/uio.ko.xz
2880221613 92588 /lib/modules/4.18.0-240.10.1.el8_3.x86_64/kernel/drivers/uio/uio_pci_generic.ko.xz

# Load UIO drivers

sudo modprobe uio_pci_generic

```
