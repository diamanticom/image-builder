# Apply patched UIO drivers on CentOS 8.2

```bash

# Kernel Version

▶ uname -r
4.18.0-193.6.3.el8_2.x86_64

# Checksum of UIO drivers

▶ cksum uio*
1609016061 109972 uio.ko.xz
1441532353 90744 uio_pci_generic.ko.xz

# Unload UIO drivers and mv original uio drivers

sudo modprobe -r uio_pci_generic
sudo mv /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz.orig
sudo mv /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz.orig

# Copy patched UIO drivers at driver's location

sudo cp uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz
sudo cp uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz

# Verify checksum of UIO drivers

▶ cksum /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz  /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz
1609016061 109972 /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio.ko.xz
1441532353 90744 /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio_pci_generic.ko.xz

# Load UIO drivers

sudo modprobe uio_pci_generic

```
