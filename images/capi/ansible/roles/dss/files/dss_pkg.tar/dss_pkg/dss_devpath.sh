#!/bin/bash

for ((RETRY=10; RETRY ; RETRY--))
do
        sleep 1;
        COUNT=$(/sbin/nvme list-subsys 2>/dev/null | grep -c $1);
        if [[ $COUNT -ne 0 ]]
        then
                echo $(/sbin/nvme list-subsys  2>/dev/null | grep -A 2 $1 | tail -n 1 | cut  -f3 -d" ")
                exit 0;
        fi;
done

echo "[$0] Failed to get nvme device path exported by nqn $1, after 10 retry" >> /dev/kmsg
exit 1 
