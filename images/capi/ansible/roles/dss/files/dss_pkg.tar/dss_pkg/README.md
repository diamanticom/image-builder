# Setup Diamanti Ultima DataPlane on a node (VM or BareMetal)

https://docs.google.com/document/d/1tLxtms-93gqNhGxo6s_66llg8MsKwmnbRgO4R3wvaXk/edit?usp=sharing

## Initial Node setup

```bash

# Create directories
mkdir -p /etc/systemd/system/default.target.wants/
mkdir -p /etc/diamanti/ultima

# Install nvme-cli pkg
dnf install -y nvme-cli

```

## Copy all the required files at respective places

```bash

$ tree dss_pkg
dss_pkg
├── centos-8.2
│   ├── README.md
│   ├── uio.ko.xz
│   └── uio_pci_generic.ko.xz
├── centos-8.3
│   ├── README.md
│   ├── uio.ko.xz
│   └── uio_pci_generic.ko.xz
├── diamanti-dss-setup.sh
├── dssapp-init.service
├── dss.conf
├── dss_devpath.sh
└── README.md

# untar dss_pkg.tar file
tar xvf /home/centos/dss_pkg.tar -C /home/centos/

# Copy dssapp-init service file and create symlink
cp /home/centos/dss_pkg/dssapp-init.service /usr/lib/systemd/system/
ln -s /usr/lib/systemd/system/dssapp-init.service /etc/systemd/system/default.target.wants/dssapp-init.service

# Copy hugepages and nvme devices attach related setup script
cp /home/centos/dss_pkg/diamanti-dss-setup.sh /usr/local/bin/
cp /home/centos/dss_pkg/dss_devpath.sh /usr/local/bin/dss_devpath.sh

# Copy dss.conf file to allow loading uio and nvme-tcp drivers to load automatically every time node reboots
cp /home/centos/dss_pkg/dss.conf /etc/modules-load.d/

# Unload uio driver, if loaded
modprobe -r uio_pci_generic

# Save original uio drivers
mv /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz.orig
mv /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz.orig

# NOTE: UIO drivers are built for both CentOS 8.2 as well as CentOS 8.3 versions

# Copy uio driver on CentOS 8.2 server
cp /home/centos/dss_pkg/centos-8.2/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz
cp /home/centos/dss_pkg/centos-8.2/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz

# Copy uio driver on CentOS 8.3 server
cp /home/centos/dss_pkg/centos-8.3/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz
cp /home/centos/dss_pkg/centos-8.3/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz

# Load uio and nvme-tcp drivers
modprobe uio_pci_generic
modprobe nvme_tcp

# Enable and start dssapp-init service
systemctl enable dssapp-init.service
systemctl start dssapp-init.service

```
