#!/usr/bin/env bash

set -e
#set -x

DSS_USER_SELECTED_DEVICES_FILE=/etc/diamanti/ultima/user_selected_devices.json
DSS_DEVICES_CONF_FILE=/etc/diamanti/ultima/dss_devices.conf

# Setup script to setup hugepages and attach nvme controllers to VFIO or UIO driver

function usage()
{
	if [ $(uname) = Linux ]; then
		options="[discover-devices|config|reset|status|cleanup|help]"
	else
		options="[config|reset|help]"
	fi

	[[ -n $2 ]] && ( echo "$2"; echo ""; )
	echo "Helper script for allocating hugepages and binding NVMe, I/OAT, VMD and Virtio devices"
	echo "to a generic VFIO kernel driver. If VFIO is not available on the system, this script"
	echo "will fall back to UIO. NVMe and Virtio devices with active mountpoints will be ignored."
	echo "All hugepage operations use default hugepage size on the system (hugepagesz)."
	echo "Usage: $(basename $1) $options"
	echo
	echo "$options - as following:"
    echo "discover-devices  Discovers all of the Ultima supported PCIe NVMe block
    devices."
	echo "config            Default mode. Allocate hugepages and bind PCI devices."
	if [ $(uname) = Linux ]; then
		echo "cleanup            Remove any orphaned files that can be left in the system after SPDK application exit"
	fi
	echo "reset             Rebind PCI devices back to their original drivers."
	echo "                  Also cleanup any leftover spdk files/resources."
	echo "                  Hugepage memory size will remain unchanged."
	if [ $(uname) = Linux ]; then
		echo "status            Print status of all SPDK-compatible devices on the system."
	fi
	echo "help              Print this help message."
	echo
	echo "The following environment variables can be specified."
	echo "HUGEMEM           Size of hugepage memory to allocate (in MB). 8192 by default."
	echo "                  For NUMA systems, the hugepages will be evenly distributed"
	echo "                  between CPU nodes"
	echo "NRHUGE            Number of hugepages to allocate. This variable overwrites HUGEMEM."
	echo "HUGENODE          Specific NUMA node to allocate hugepages on. To allocate"
	echo "                  hugepages on multiple nodes run this script multiple times -"
	echo "                  once for each node."
	echo "PCI_WHITELIST"
	echo "PCI_BLACKLIST     Whitespace separated list of PCI devices (NVMe, I/OAT, VMD, Virtio)."
	echo "                  Each device must be specified as a full PCI address."
	echo "                  E.g. PCI_WHITELIST=\"0000:01:00.0 0000:02:00.0\""
	echo "                  To blacklist all PCI devices use a non-valid address."
	echo "                  E.g. PCI_WHITELIST=\"none\""
	echo "                  If PCI_WHITELIST and PCI_BLACKLIST are empty or unset, all PCI devices"
	echo "                  will be bound."
	echo "                  Each device in PCI_BLACKLIST will be ignored (driver won't be changed)."
	echo "                  PCI_BLACKLIST has precedence over PCI_WHITELIST."
	echo "TARGET_USER       User that will own hugepage mountpoint directory and vfio groups."
	echo "                  By default the current user will be used."
	echo "DRIVER_OVERRIDE   Disable automatic vfio-pci/uio_pci_generic selection and forcefully"
	echo "                  bind devices to the given driver."
	echo "                  E.g. DRIVER_OVERRIDE=uio_pci_generic or DRIVER_OVERRIDE=/home/public/dpdk/build/kmod/igb_uio.ko"
	exit 0
}

mode=$1

if [ -z "$mode" ]; then
	mode="config"
fi

: ${HUGEMEM:=8192}
: ${PCI_WHITELIST:=""}
: ${PCI_BLACKLIST:=""}

# Enforce minimum required capacity as 200GiB
: ${DSS_NVME_DEVICE_CAPACITY_BYTES_MINIMUM:=214748364800}

# Enforce maximum supported capacity as 8TiB
: ${DSS_NVME_DEVICE_CAPACITY_BYTES_MAXIMUM:=8796093022208}

# DSS currently supports only 4 PCIe NVMe devices
: ${DSS_SUPPORTED_DEVICES_COUNT:=4}

# Auto selected PCIe NVMe device info list
# to be used for device config json file
declare -ga auto_selected_devices

# User selected PCIe NVMe device info list
# to be used for device config json file
declare -ga user_selected_devices

# Contains user-selected PCIe NVMe device names
declare -ga user_nvme_bdevs

# PCIe NVMe device list
declare -ga dss_supported_devices

# Contains Ultima supported discovered PCIe NVMe device names
declare -ga dss_nvme_bdevs_discovered

if [ -n "$NVME_WHITELIST" ]; then
	PCI_WHITELIST="$PCI_WHITELIST $NVME_WHITELIST"
fi

if [ -n "$SKIP_PCI" ]; then
	PCI_WHITELIST="none"
fi

if [ -z "$TARGET_USER" ]; then
	TARGET_USER="$SUDO_USER"
	if [ -z "$TARGET_USER" ]; then
		TARGET_USER=$(logname 2>/dev/null) || true
	fi
fi

# Function to check whether the supplied nvme block device
# is a valid block device to be claimed under Ultima Storage.
#
# Device selection filters are as follows:
# 	- No read-only device
# 	- No filesystem on device
#	- No block device partition
#	- No block device mount
#	- No nvme-of block device (only PCIe)
#	- Minimum drive capacity 200GiB
#	- Maximum drive capacity 8TiB

function is_dss_supported_nvme_device() {
    local nvmebdev=$1
    local part fstype mount
    # Check if there is any partition
    # exists on the nvme block device
    partcnt=$(lsblk -no PKNAME  /dev/${nvmebdev} | wc -w)
    if [[ "$partcnt" -gt "0" ]]; then
        # DSS doesn't support partiotioned block device
        echo "false" 
        return
    fi

    # Check if any filesystem exists
    # on the nvme block device.
    fstype=$(lsblk -no FSTYPE /dev/${nvmebdev})
    if [[ ${fstype} != "" ]]; then
        # DSS doesn't support block device containing filesystem
        echo "false" 
        return
    fi

    # If no filesystem found then we don't expect
    # any mountpoint to exist against that device
    mountpoint=$(lsblk -no MOUNTPOINT /dev/${nvmebdev} | wc -w)
    if [[ "$mountpoint" -gt "0" ]]; then
        # DSS doesn't support block device ccurently being mounted
        echo "false" 
        return
    fi

    # Make sure that the block device is not read-only device
    readonly=$(lsblk -no RO  /dev/${nvmebdev})
    if [[ ${readonly} == 1 ]]; then
        # DSS doesn't support read-only block device
        echo "false" 
        return
    fi

    # Block device size or capacity should be in
    # the range of DSS supported nvme block device
    capacity=$(lsblk -b -no SIZE /dev/${nvmebdev})
    if [[ "${capacity}" -lt "${DSS_NVME_DEVICE_CAPACITY_BYTES_MINIMUM}" || \
            "${capacity}" -gt "${DSS_NVME_DEVICE_CAPACITY_BYTES_MAXIMUM}" ]]; then
        # DSS currently supports minimum 200GiB and maximum 8TiB nvme device
        echo "false" 
        return
    fi

    # DSS supported PCIe nvme block device
    echo "true" 
    return
}

# Check if PCI device is on PCI_WHITELIST and not on PCI_BLACKLIST
# Env:
# if PCI_WHITELIST is empty assume device is whitelistened
# if PCI_BLACKLIST is empty assume device is NOT blacklistened
# Params:
# $1 - PCI BDF
function pci_can_use() {
	local i

	# The '\ ' part is important
	if [[ " $PCI_BLACKLIST " =~ \ $1\  ]] ; then
		return 1
	fi

	if [[ -z "$PCI_WHITELIST" ]]; then
		#no whitelist specified, bind all devices
		return 0
	fi

	for i in $PCI_WHITELIST; do
		if [ "$i" == "$1" ] ; then
			return 0
		fi
	done

	return 1
}

# This function will ignore PCI PCI_WHITELIST and PCI_BLACKLIST
function iter_all_pci_class_code() {
	local class
	local subclass
	local progif
	class="$(printf %02x $((0x$1)))"
	subclass="$(printf %02x $((0x$2)))"
	progif="$(printf %02x $((0x$3)))"

	if hash lspci &>/dev/null; then
		if [ "$progif" != "00" ]; then
			lspci -mm -n -D | \
				grep -i -- "-p${progif}" | \
				awk -v cc="\"${class}${subclass}\"" -F " " \
				'{if (cc ~ $2) print $1}' | tr -d '"'
		else
			lspci -mm -n -D | \
				awk -v cc="\"${class}${subclass}\"" -F " " \
				'{if (cc ~ $2) print $1}' | tr -d '"'
		fi
	elif hash pciconf &>/dev/null; then
		local addr=($(pciconf -l | grep -i "class=0x${class}${subclass}${progif}" | \
			cut -d$'\t' -f1 | sed -e 's/^[a-zA-Z0-9_]*@pci//g' | tr ':' ' '))
		printf "%04x:%02x:%02x:%x\n" ${addr[0]} ${addr[1]} ${addr[2]} ${addr[3]}
	else
		echo "Missing PCI enumeration utility" >&2
		exit 1
	fi
}

# This function will ignore PCI PCI_WHITELIST and PCI_BLACKLIST
function iter_all_pci_dev_id() {
	local ven_id
	local dev_id
	ven_id="$(printf %04x $((0x$1)))"
	dev_id="$(printf %04x $((0x$2)))"

	if hash lspci &>/dev/null; then
		lspci -mm -n -D | awk -v ven="\"$ven_id\"" -v dev="\"${dev_id}\"" -F " " \
			'{if (ven ~ $3 && dev ~ $4) print $1}' | tr -d '"'
	elif hash pciconf &>/dev/null; then
		local addr=($(pciconf -l | grep -i "chip=0x${dev_id}${ven_id}" | \
			cut -d$'\t' -f1 | sed -e 's/^[a-zA-Z0-9_]*@pci//g' | tr ':' ' '))
		printf "%04x:%02x:%02x:%x\n" ${addr[0]} ${addr[1]} ${addr[2]} ${addr[3]}
	else
		echo "Missing PCI enumeration utility" >&2
		exit 1
	fi
}

function iter_pci_dev_id() {
	local bdf=""

	for bdf in $(iter_all_pci_dev_id "$@"); do
		if pci_can_use "$bdf"; then
			echo "$bdf"
		fi
	done
}

# This function will filter out PCI devices using PCI_WHITELIST and PCI_BLACKLIST
# See function pci_can_use()
function iter_pci_class_code() {
	local bdf=""

	for bdf in $(iter_all_pci_class_code "$@"); do
		if pci_can_use "$bdf"; then
			echo "$bdf"
		fi
	done
}
# In monolithic kernels the lsmod won't work. So
# back that with a /sys/modules. We also check
# /sys/bus/pci/drivers/ as neither lsmod nor /sys/modules might
# contain needed info (like in Fedora-like OS).
function check_for_driver {
	if lsmod | grep -q ${1//-/_}; then
		return 1
	fi

	if [[ -d /sys/module/${1} || \
			-d /sys/module/${1//-/_} || \
			-d /sys/bus/pci/drivers/${1} || \
			-d /sys/bus/pci/drivers/${1//-/_} ]]; then
		return 2
	fi
	return 0
}

function pci_dev_echo() {
	local bdf="$1"
	local vendor
	local device
	vendor="$(cat /sys/bus/pci/devices/$bdf/vendor)"
	device="$(cat /sys/bus/pci/devices/$bdf/device)"
	shift
	echo "$bdf (${vendor#0x} ${device#0x}): $*"
}

function linux_bind_driver() {
	bdf="$1"
	driver_name="$2"
	old_driver_name="no driver"
	ven_dev_id=$(lspci -n -s $bdf | cut -d' ' -f3 | sed 's/:/ /')

	if [ -e "/sys/bus/pci/devices/$bdf/driver" ]; then
		old_driver_name=$(basename $(readlink /sys/bus/pci/devices/$bdf/driver))

		if [ "$driver_name" = "$old_driver_name" ]; then
			pci_dev_echo "$bdf" "Already using the $old_driver_name driver"
			return 0
		fi

		echo "$ven_dev_id" > "/sys/bus/pci/devices/$bdf/driver/remove_id" 2> /dev/null || true
		echo "$bdf" > "/sys/bus/pci/devices/$bdf/driver/unbind"
	fi

	pci_dev_echo "$bdf" "$old_driver_name -> $driver_name"

	echo "$ven_dev_id" > "/sys/bus/pci/drivers/$driver_name/new_id" 2> /dev/null || true
	echo "$bdf" > "/sys/bus/pci/drivers/$driver_name/bind" 2> /dev/null || true

	iommu_group=$(basename $(readlink -f /sys/bus/pci/devices/$bdf/iommu_group))
	if [ -e "/dev/vfio/$iommu_group" ]; then
		if [ -n "$TARGET_USER" ]; then
			chown "$TARGET_USER" "/dev/vfio/$iommu_group"
		fi
	fi
}

function linux_unbind_driver() {
	local bdf="$1"
	local ven_dev_id
	ven_dev_id=$(lspci -n -s $bdf | cut -d' ' -f3 | sed 's/:/ /')
	local old_driver_name="no driver"

	if [ -e "/sys/bus/pci/devices/$bdf/driver" ]; then
		old_driver_name=$(basename $(readlink /sys/bus/pci/devices/$bdf/driver))
		echo "$ven_dev_id" > "/sys/bus/pci/devices/$bdf/driver/remove_id" 2> /dev/null || true
		echo "$bdf" > "/sys/bus/pci/devices/$bdf/driver/unbind"
	fi

	pci_dev_echo "$bdf" "$old_driver_name -> no driver"
}

function linux_hugetlbfs_mounts() {
	mount | grep ' type hugetlbfs ' | awk '{ print $3 }'
}

function get_nvme_name_from_bdf {
	local blknames=()

	set +e
	nvme_devs=$(lsblk -d --output NAME | grep "^nvme")
	set -e
	for dev in $nvme_devs; do
		link_name=$(readlink /sys/block/$dev/device/device) || true
		if [ -z "$link_name" ]; then
			link_name=$(readlink /sys/block/$dev/device)
		fi
		link_bdf=$(basename "$link_name")
		if [ "$link_bdf" = "$1" ]; then
			blknames+=($dev)
		fi
	done

	printf '%s\n' "${blknames[@]}"
}

# Function to check whether user has selected PCIe
# NVMe block devices to be managed by Ultima Storage
# Returns "true" and "false" string as ouput

function check_userselected_devices() {
    # Sanity check against user selected file before proceeding
    if [ ! -f "$DSS_USER_SELECTED_DEVICES_FILE" ]; then
        echo "false"
        return
    fi

	# Since "user_devices.json" file is pre existing
    # with no nvme device entry so check if user has
    # updated this file with PCIe NVMe device entries.
	nvmedevcnt=$(jq '.block_devices.pcie_nvme_devices | length' $DSS_USER_SELECTED_DEVICES_FILE)
	if [[ "$nvmedevcnt" -gt "0" ]]; then
		echo "true" 
    else
        echo "false"
    fi
}

# Function to return Ultima supported PCIe NVMe
# device info structure correspondig to a ctrl BDF

function get_dss_supported_devinfo() {
	bdf=$1

	for devinfo in "${dss_supported_devices[@]}"; do
		devlist_bdf=$(echo "${devinfo}" | jq -r '.bdf')
		if [[ "$devlist_bdf" == "$bdf" ]]; then
			echo "${devinfo}"
			return
		fi 
	done
}

# Function to process controller attach against user
# selected PCIe NVMe block device. It first verifies
# the required number of nvme devices are provided or
# not. If not then returns appropriate error.
# If required number of devices are found then it
# creats Ultima managed device config file.

function process_user_selected_devices() {
	# Fetch all of the user-selected nvme devices from file
	user_devices=$(jq '.block_devices.pcie_nvme_devices[]' $DSS_USER_SELECTED_DEVICES_FILE | sed 's/"//g' | uniq)

	# Convert the user_devices strings output into an array
	readarray -t nvmedevlist < <(echo ${user_devices})

	# Iterate through all the user-selected devices and
	# and verify that the nvme device is DSS supported.
	# Ensure that the required number of user-selected
	# DSS supported devices are found to be able to
	# proceed further for device attach to UIO driver.
	count=0
	local dss_devices_config_json=()
	for nvmebdev in ${nvmedevlist[@]}; do
		if [ ! -b "/dev/$nvmebdev" ]; then
			continue
		fi

		bdf=$(basename `readlink /sys/block/${nvmebdev}/device/device`)
		if [[ -z "$bdf" ]]; then
			continue
		fi

		# Since DSS supported devices are discovered
		# so lets check if this nvme device belongs 
		# to the dss_supported_devices list or not.

		devinfo=$(get_dss_supported_devinfo ${bdf})
		if [[ -z "${devinfo}" ]]; then
			continue
		fi

		# Add into user_selected device list
		user_selected_devices[count]=$(echo "${devinfo}")
		user_nvme_bdevs[count]=$(echo "[ BDEV: ${nvmebdev}, BDF: ${bdf} ]")
		dss_devices_config_json[count]=$(echo "${devinfo},")
		count=$((count + 1))
		
		# Check if we already got the required number of devices 
		if [[ "$count" == "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
			break
		fi
	done

    #
    # TODO: DSS is now supporting PCIe NVMe controllers having
    #       multiple namespaces hence if there is any requirement
    #       in future to support multiple such controllers then
    #       we need to do additional changes to take care of that.
    #
    #       - At present on AWS, each controller has single
    #         namespace and only required number of devices
    #         are attached to the instance so there is no
    #         additional care required.
    #       - On GCP, there is a single controller with multiple
    #         namespaces are exported. Only required number of
    #         nvme block devices are attached to the instance hence
    #         there is no additional care required.
    #       - Cloud environment or on-prem, if user selects PCIe
    #         nvme block devices to be managed by DSS then new
    #         code is required to be added to hande all the possible
    #         cases around that.
    #       - We need to ensure that all the namespaces against
    #         the controller is selected by the user. Controller
    #         detach and attach are done against all the namespaces
    #         but not partially.
    #

	# Make sure that we got required number of DSS supported
	# PCIe NVMe devices against user's drive selection
	if [[ ${#user_selected_devices[@]} -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
		return
	fi

	# Convert into json format
    dss_devices_config=$({
    	echo '{"pcie_nvme_devlist": ['
        echo "${dss_devices_config_json[@]}" | sed '$s/,$//'
        echo ']}'
	})

	# Sanity check before writing device configuration file
	devcount=$(echo ${dss_devices_config} | jq '.pcie_nvme_devlist | length')
	if [[ "$devcount" -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
		return
	fi

	# Create DSS device config file
	echo "${dss_devices_config}" | jq . > ${DSS_DEVICES_CONF_FILE} 2>&1
}

# Function to select Ultima supported PCIe NVMe devices.
# If required number of devices are not found then it
# reports appropriate error. If required number of
# devices are found then it creats the device config file

function process_auto_select_devices() {
	dss_devices_sorted=$(echo "${dss_supported_devices[@]}" | jq -s -c  'sort_by(.capacity | tonumber) | reverse[]')

	# If there are more than required number of
    # PCIe NVMe block devices exists then select
	# required number of block devices out of them
	local dss_devices_sorted_config=()
	count=0
	readarray -t devinfolist < <(echo ${dss_devices_sorted} | jq -s . | jq -c '.[]')
	for devinfo in "${devinfolist[@]}"; do
		auto_selected_devices[count]=$(echo "${devinfo}")
		dss_devices_sorted_config[count]=$(echo "${devinfo},")
		count=$((count + 1))
		if [[ "$count" -ge "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
			break
		fi
	done

	if [[ "$count" -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
		return
	fi

	# Setup DSS device config file for json format
    dss_devices_config=$({
    	echo '{"pcie_nvme_devlist": ['
        echo "${dss_devices_sorted_config[@]}" | sed '$s/,$//'
        echo ']}'
	})

	# Sanity check before creating drive config file
	devcount=$(echo ${dss_devices_config} | jq '.pcie_nvme_devlist | length')
	if [[ "$devcount" -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
		return
	fi

	# Create DSS device config file
	echo "${dss_devices_config}" | jq . > ${DSS_DEVICES_CONF_FILE} 2>&1
}

# Function to process attach of all of the NVMe controllers
# which are being managed or going to be managed by Ultima. 
# It reads the internally managed device configuration file
# every system reboot and uses those controller BDFs for attach.

function attach_dss_devices() {
    # Read DSS device config file
    if [[ ! -f "${DSS_DEVICES_CONF_FILE}" ]]; then
        echo -e "Diamanti DSS devices Configuration file '${DSS_DEVICES_CONF_FILE}' doesn't exist"
        return 1
    fi

    # Get all the BDFs from the DSS device config
    # file and attach those devices to UIO driver

	# Get the devices count from devices config file
	drvcnt=$(jq '.pcie_nvme_devlist | length' ${DSS_DEVICES_CONF_FILE})
	if [[ "$drvcnt" != "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
		echo -e "${DSS_DEVICES_CONF_FILE} does not contain valid or expected number [$DSS_SUPPORTED_DEVICES_COUNT] of entries"
		return 1
	fi

	# Get the list of PCIe NVMe controller's BDF
    bdflist=$(jq '.pcie_nvme_devlist[].bdf' ${DSS_DEVICES_CONF_FILE} | sed 's/"//g' | tr '\n' " ")
    
	# set PCI_WHITELIST="BDF1 BDF2 BDF3 BDF4"
	PCI_WHITELIST="$bdflist"

	for bdf in ${bdflist}; do
		blknames=()
		if ! pci_can_use $bdf; then
			pci_dev_echo "$bdf" "Skipping un-whitelisted NVMe controller at $bdf"
			continue
		fi

		mount=false
		for blkname in $(get_nvme_name_from_bdf $bdf); do
			mountpoints=$(lsblk /dev/$blkname --output MOUNTPOINT -n | wc -w)
			if [ "$mountpoints" != "0" ]; then
				mount=true
				blknames+=($blkname)
			fi
		done

		if ! $mount; then
			linux_bind_driver "$bdf" "$driver_name"
		else
			for name in "${blknames[@]}"; do
				pci_dev_echo "$bdf" "Active mountpoints on /dev/$name, so not binding PCI dev"
			done
		fi
	done

	echo "1" > "/sys/bus/pci/rescan"
}

function configure_linux_pci {
	local driver_path=""
	driver_name=""
	if [[ -n "${DRIVER_OVERRIDE}" ]]; then
		driver_path="$DRIVER_OVERRIDE"
		driver_name="${DRIVER_OVERRIDE##*/}"
		# modprobe and the sysfs don't use the .ko suffix.
		driver_name=${driver_name%.ko}
		# path = name -> there is no path
		if [[ "$driver_path" = "$driver_name" ]]; then
			driver_path=""
		fi
		# igb_uio is a common driver to override with and it depends on uio.
		if [[ "$driver_name" = "igb_uio" ]]; then
			modprobe uio
		fi
	elif [[ -n "$(ls /sys/kernel/iommu_groups)" || \
	     (-e /sys/module/vfio/parameters/enable_unsafe_noiommu_mode && \
	     "$(cat /sys/module/vfio/parameters/enable_unsafe_noiommu_mode)" == "Y") ]]; then
		driver_name=vfio-pci
	elif modinfo uio_pci_generic >/dev/null 2>&1; then
		driver_name=uio_pci_generic
	else
		echo "No valid drivers found [vfio-pci, uio_pci_generic, igb_uio]. Please either enable the vfio-pci or uio_pci_generic"
		echo "kernel modules, or have SPDK build the igb_uio driver by running ./configure --with-igb-uio-driver and recompiling."
		return 1
	fi

	# modprobe assumes the directory of the module. If the user passes in a path, we should use insmod
	if [[ -n "$driver_path" ]]; then
		insmod $driver_path || true
	else
		modprobe $driver_name
	fi

	# Check if DSS device config file exist, if it exist then
	# attach all PCIe NVMe devices using device config BDFs
	DSS_DEVICES_CONFIG_FILE_EXIST=$(dss_device_config_file_exist)
	if [[ "${DSS_DEVICES_CONFIG_FILE_EXIST}" == "true" ]]; then
		# Attach DSS devices to UIO driver
		attach_dss_devices
	else
		# First discover DSS supported PCIe NVMe block devices
		discover_pcienvme_dss_supported_devices

		# Make sure we could discover required number of DSS
		# supported PCIe NVMe devices for automatic selection
		if [[ "${#dss_supported_devices[@]}" -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
			echo -e "Required number of Ultima supported PCIe NVMe block devices are not found"
			echo -e "Devices required: [ $DSS_SUPPORTED_DEVICES_COUNT ], Found (discovery): [ ${#dss_supported_devices[@]} ]"
			exit 1
		fi

		# Check if user input is provided for PCIe NVMe devices selection
		# If user is not selecting devices then select devices automatically
		IS_USER_SELECTED_DEVICES=$(check_userselected_devices)
		if [[ "${IS_USER_SELECTED_DEVICES}" == "true" ]]; then

			process_user_selected_devices

			# Make sure that we got required number of DSS supported
			# PCIe NVMe devices against user's drive selection
			if [[ "${#user_selected_devices[@]}" -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
				echo -e "Required number of Ultima supported PCIe NVMe block devices are not found"
                echo -e "Devices required: [ $DSS_SUPPORTED_DEVICES_COUNT ], Found (user-selection): [ ${#user_selected_devices[@]} ]"
				echo -e "[ ${user_nvme_bdevs[@]} ]"
				exit 1
			fi
			# Attach user selected nvme devices.
			attach_dss_devices
		else
			# Select required number of PCIe NVMe devices
			# automatically and process it further

			process_auto_select_devices

			# Make sure that we found required number of
			# devices before proceeding for device attach
			if [[ "${#auto_selected_devices[@]}" -lt "$DSS_SUPPORTED_DEVICES_COUNT" ]]; then
				echo -e "Required number of Ultima supported PCIe NVMe block devices are not found"
				echo -e "Devices required: [ $DSS_SUPPORTED_DEVICES_COUNT ], Found (auto-selection): [ ${#auto_selected_devices[@]} ]"
				exit 1
			fi
			# Attach automatically selected devices
			attach_dss_devices
		fi
	fi
}

function cleanup_linux {
	shopt -s extglob nullglob
	dirs_to_clean=""
	dirs_to_clean="$(echo {/var/run,/tmp}/dpdk/spdk{,_pid}+([0-9])) "
	if [[ -d $XDG_RUNTIME_DIR && $XDG_RUNTIME_DIR != *" "* ]]; then
		dirs_to_clean+="$(readlink -e assert_not_empty $XDG_RUNTIME_DIR/dpdk/spdk{,_pid}+([0-9]) || true) "
	fi

	files_to_clean=""
	for dir in $dirs_to_clean; do
		files_to_clean+="$(echo $dir/*) "
	done
	shopt -u extglob nullglob

	files_to_clean+="$(ls -1 /dev/shm/* | \
	grep -E '(spdk_tgt|iscsi|vhost|nvmf|rocksdb|bdevio|bdevperf|vhost_fuzz|nvme_fuzz)_trace|spdk_iscsi_conns' || true) "
	files_to_clean="$(readlink -e assert_not_empty $files_to_clean || true)"
	if [[ -z "$files_to_clean" ]]; then
		echo "Clean"
		return 0;
	fi

	shopt -s extglob
	for fd_dir in $(echo /proc/+([0-9])); do
		opened_files+="$(readlink -e assert_not_empty $fd_dir/fd/* || true)"
	done
	shopt -u extglob

	if [[ -z "$opened_files" ]]; then
		echo "Can't get list of opened files!"
		exit 1
	fi

	echo 'Cleaning'
	for f in $files_to_clean; do
		if ! echo "$opened_files" | grep -E -q "^$f\$"; then
			echo "Removing:    $f"
			rm $f
		else
			echo "Still open: $f"
		fi
	done

	for dir in $dirs_to_clean; do
	if ! echo "$opened_files" | grep -E -q "^$dir\$"; then
		echo "Removing:    $dir"
		rmdir $dir
	else
		echo "Still open: $dir"
	fi
	done
	echo "Clean"

	unset dirs_to_clean files_to_clean opened_files
}

function configure_linux {
	configure_linux_pci
	hugetlbfs_mounts=$(linux_hugetlbfs_mounts)

	if [ -z "$hugetlbfs_mounts" ]; then
		hugetlbfs_mounts=/mnt/huge
		echo "Mounting hugetlbfs at $hugetlbfs_mounts"
		mkdir -p "$hugetlbfs_mounts"
		mount -t hugetlbfs nodev "$hugetlbfs_mounts"
	fi

	if [ -z "$HUGENODE" ]; then
		hugepages_target="/proc/sys/vm/nr_hugepages"
	else
		hugepages_target="/sys/devices/system/node/node${HUGENODE}/hugepages/hugepages-${HUGEPGSZ}kB/nr_hugepages"
	fi

	echo "$NRHUGE" > "$hugepages_target"
	allocated_hugepages=$(cat $hugepages_target)
	if [ "$allocated_hugepages" -lt "$NRHUGE" ]; then
		echo ""
		echo "## ERROR: requested $NRHUGE hugepages but only $allocated_hugepages could be allocated."
		echo "## Memory might be heavily fragmented. Please try flushing the system cache, or reboot the machine."
		exit 1
	fi

	if [ "$driver_name" = "vfio-pci" ]; then
		if [ -n "$TARGET_USER" ]; then
			for mount in $hugetlbfs_mounts; do
				chown "$TARGET_USER" "$mount"
				chmod g+w "$mount"
			done
		fi

		MEMLOCK_AMNT=$(ulimit -l)
		if [ "$MEMLOCK_AMNT" != "unlimited" ] ; then
			MEMLOCK_MB=$(( MEMLOCK_AMNT / 1024 ))
			echo ""
			echo "Current user memlock limit: ${MEMLOCK_MB} MB"
			echo ""
			echo "This is the maximum amount of memory you will be"
			echo "able to use with DPDK and VFIO if run as current user."
			echo -n "To change this, please adjust limits.conf memlock "
			echo "limit for current user."

			if [ $MEMLOCK_AMNT -lt 65536 ] ; then
				echo ""
				echo "## WARNING: memlock limit is less than 64MB"
				echo -n "## DPDK with VFIO may not be able to initialize "
				echo "if run as current user."
			fi
		fi
	fi

	if [ ! -f /dev/cpu/0/msr ]; then
		# Some distros build msr as a module.  Make sure it's loaded to ensure
		#  DPDK can easily figure out the TSC rate rather than relying on 100ms
		#  sleeps.
		modprobe msr || true
	fi
}

function reset_linux_pci {
	# NVMe
	set +e
	check_for_driver nvme
	driver_loaded=$?
	set -e

    # Read DSS device config file
    if [[ ! -f "${DSS_DEVICES_CONF_FILE}" ]]; then
        echo -e "Diamanti DSS devices Configuration file '${DSS_DEVICES_CONF_FILE}' doesn't exist"
        return
    fi

    # Get all the BDFs from the DSS device config
    # file and detach those devices from UIO driver
    bdflist=$(jq '.pcie_nvme_devlist[].bdf' ${DSS_DEVICES_CONF_FILE} | sed 's/"//g' | tr '\n' " ")

    # set PCI_WHITELIST="BDF1 BDF2 BDF3 BDF4"
    PCI_WHITELIST="$bdflist"

	for bdf in ${bdflist[@]}; do
		if ! pci_can_use $bdf; then
			pci_dev_echo "$bdf" "Skipping un-whitelisted NVMe controller $blkname"
			continue
		fi
		if [ $driver_loaded -ne 0 ]; then
			linux_bind_driver "$bdf" nvme
		else
			linux_unbind_driver "$bdf"
		fi
	done

	echo "1" > "/sys/bus/pci/rescan"
}

function reset_linux {
	reset_linux_pci
	for mount in $(linux_hugetlbfs_mounts); do
		rm -f "$mount"/spdk*map_*
	done
	rm -f /run/.spdk*
}

function status_linux {
	echo "Hugepages"
	printf "%-6s %10s %8s / %6s\n" "node" "hugesize"  "free" "total"

	numa_nodes=0
	shopt -s nullglob
	for path in /sys/devices/system/node/node?/hugepages/hugepages-*/; do
		numa_nodes=$((numa_nodes + 1))
		free_pages=$(cat $path/free_hugepages)
		all_pages=$(cat $path/nr_hugepages)

		[[ $path =~ (node[0-9]+)/hugepages/hugepages-([0-9]+kB) ]]

		node=${BASH_REMATCH[1]}
		huge_size=${BASH_REMATCH[2]}

		printf "%-6s %10s %8s / %6s\n" $node $huge_size $free_pages $all_pages
	done
	shopt -u nullglob

	# fall back to system-wide hugepages
	if [ "$numa_nodes" = "0" ]; then
		free_pages=$(grep HugePages_Free /proc/meminfo | awk '{ print $2 }')
		all_pages=$(grep HugePages_Total /proc/meminfo | awk '{ print $2 }')
		node="-"
		huge_size="$HUGEPGSZ"

		printf "%-6s %10s %8s / %6s\n" $node $huge_size $free_pages $all_pages
	fi

	echo ""
	echo "NVMe devices"

	echo -e "BDF\t\tVendor\tDevice\tNUMA\tdriver\t\tDevice name"
	for bdf in $(iter_all_pci_class_code 01 08 02); do
		driver=$(grep DRIVER /sys/bus/pci/devices/$bdf/uevent |awk -F"=" '{print $2}')
		if [ "$numa_nodes" = "0" ]; then
			node="-"
		else
			node=$(cat /sys/bus/pci/devices/$bdf/numa_node)
		fi
		device=$(cat /sys/bus/pci/devices/$bdf/device)
		vendor=$(cat /sys/bus/pci/devices/$bdf/vendor)
		if [ "$driver" = "nvme" ] && [ -d /sys/bus/pci/devices/$bdf/nvme ]; then
			name="\t"$(ls /sys/bus/pci/devices/$bdf/nvme);
		else
			name="-";
		fi
		echo -e "$bdf\t${vendor#0x}\t${device#0x}\t$node\t${driver:--}\t\t$name";
	done
}

# Function to check the existence of device config file

function dss_device_config_file_exist() {
    if [[ -f "$DSS_DEVICES_CONF_FILE" ]]; then
        echo "true"
    else
        echo "false"
    fi
}

# Function to discover all of the PCIe NVMe block devices
# on the system which are supported by Ultima Storage

function discover_pcienvme_dss_supported_devices() {
	echo "1" > "/sys/bus/pci/rescan"
    nvmebdevspath=$(readlink -f /sys/block/nvme*)
    nvmedevspathlist=($nvmebdevspath)
    
	count=0
    attr_transport_pci="ATTRS{transport}==\"pcie\""
    for bdev in "${nvmedevspathlist[@]}"; do
        nvmebdev=$(basename $bdev)
		# Skip virtual nvme-of device
        if [[ $nvmebdev == "nvme*" ]]; then
            continue
        fi

		# Select only PCIe NVMe block devices
        transport=$(udevadm info --attribute-walk --name /dev/${nvmebdev} | grep "ATTRS{transport}" | tr -d ' ')
        if [[ $transport != ${attr_transport_pci} ]]; then
            continue
        fi

		# Skip all of the NVMe devices which are not supported by DSS
        local dss_capable_device=$(is_dss_supported_nvme_device $nvmebdev)
        if [[ "${dss_capable_device}" == "false" ]]; then
            continue
        fi

        bdf=$(basename `readlink /sys/block/${nvmebdev}/device/device`)

        # Prepare device info for dss drive json config file update
        capacity=$(lsblk -b -no SIZE /dev/${nvmebdev})
        serial_number=$(lsblk -no SERIAL /dev/${nvmebdev})
        model=$(lsblk -no MODEL /dev/${nvmebdev})
        vendor="$(cat /sys/bus/pci/devices/$bdf/vendor)"
        device="$(cat /sys/bus/pci/devices/$bdf/device)"
        devinfo=$(echo "{\"bdf\":\"$bdf\",\"capacity\":\"$capacity\",\"serial_number\":\"$serial_number\",\"model\":\"$model\",\"vendor\":\"$vendor\",\"device\":\"$device\"}")

        dss_supported_devices[count]=$(echo "${devinfo}")
        dss_nvme_bdevs_discovered[count]=$(echo "${nvmebdev}")

        count=$((count + 1))
    done
}

function discover_block_devices_linux() {

    # Discover Ultima supported PCIe NVMe block devices
    discover_pcienvme_dss_supported_devices
}

# Function to return the json object which
# contains all of the PCIe NVMe block devices
# which are suported by Ultima, not necessarily
# all of them being managed or claimed by Ultima.

function get_block_devices_json() {
    local nvmebdevs_temp=()
    for bdev in ${dss_nvme_bdevs_discovered[@]}; do
        nvmebdevs_tmp+=$(echo "\"$bdev\",")
    done

    # Convert nvmebdevs_tmp array into json format and output it
    nvmebdevs_json=$({
		echo '{"block_devices":'
        echo '{"pcie_nvme_devices": ['
        echo "${nvmebdevs_tmp[@]}" | sed '$s/,$//'
        echo ']}}'
    })

    echo "${nvmebdevs_json}" | jq .
}

if [ $(uname) = Linux ]; then
	HUGEPGSZ=$(( $(grep Hugepagesize /proc/meminfo | cut -d : -f 2 | tr -dc '0-9') ))
	HUGEPGSZ_MB=$(( HUGEPGSZ / 1024 ))
	: ${NRHUGE=$(( (HUGEMEM + HUGEPGSZ_MB - 1) / HUGEPGSZ_MB ))}

	if [ "$mode" == "config" ]; then
		configure_linux
	elif [ "$mode" == "cleanup" ]; then
		cleanup_linux
	elif [ "$mode" == "reset" ]; then
		reset_linux
	elif [ "$mode" == "status" ]; then
		status_linux
    elif [ "$mode" == "discover-devices" ]; then
        discover_block_devices_linux
		get_block_devices_json
	elif [ "$mode" == "help" ]; then
		usage $0
	else
		usage $0 "Invalid argument '$mode'"
	fi
fi
