#!/bin/bash

echo $(/sbin/nvme list-subsys  | grep -A 2 $1 | tail -n 1 | cut  -f3 -d" ")
