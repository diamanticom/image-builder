## Operating System Version

```bash
▶ cat /etc/diamanti-release
CentOS Linux release 8.2.2004 (Core) 8.2.0-727

```

## Kernel Version

```bash

▶ uname -r
4.18.0-193.6.3.el8_2.x86_64

```

## Configuration file to load uio and nvme-tcp drivers at boot time

```bash

▶ cat /etc/modules-load.d/dss.conf
uio_pci_generic
nvme-tcp

```

## Checksum of patched UIO kernel drivers

```bash

# Unload UIO drivers
▶  modprobe -r uio_pci_generic

# Copy patched UIO drivers
▶  cp /tmp/uio.ko.xz /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio.ko.xz
▶  cp /tmp/uio_pci_generic.ko.xz /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio_pci_generic.ko.xz

# Verify checksum of UIO drivers
▶ cksum  /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio.ko.xz
1609016061 109972 /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio.ko.xz
▶ cksum /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio_pci_generic.ko.xz
1441532353 90744 /lib/modules/4.18.0-193.6.3.el8_2.x86_64/kernel/drivers/uio/uio_pci_generic.ko.xz

```

## AWS Cloudformation scripts to setup Diamanti Node

```bash

▶ cat /var/lib/cloud/scripts/per-instance/diamanti-node-prep.sh
#!/bin/bash

# Sets up the machineid when a new instance is initialized

# remove the existing machine-id
rm /etc/machine-id

#generate a new one
systemd-machine-id-setup

# setup the zone
echo "Setting Zone config"

echo "NAME=`curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone`" > /etc/diamanti/zone.conf

```

## Manual steps to prepare for DSS-AWS AMI creation

### Copy all the required files at respective places

```bash

tar xvf /home/diamanti/dss_aws_ami.tar -C /home/diamanti/
sudo cp /home/diamanti/dss_aws_ami/dssapp-init.service /usr/lib/systemd/system/
sudo ln -s  /usr/lib/systemd/system/dssapp-init.service /etc/systemd/system/default.target.wants/dssapp-init.service
sudo cp /home/diamanti/dss_aws_ami/diamanti-dss-setup.sh /usr/local/bin/
sudo cp /home/diamanti/dss_aws_ami/dss_devpath.sh /usr/local/bin/dss_devpath.sh
sudo cp /home/diamanti/dss_aws_ami/dss.conf  /etc/modules-load.d/
sudo modprobe -r uio_pci_generic
sudo mv /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz.orig
sudo mv /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz.orig
sudo cp /home/diamanti/dss_aws_ami/uio.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio.ko.xz
sudo cp /home/diamanti/dss_aws_ami/uio_pci_generic.ko.xz /lib/modules/`uname -r`/kernel/drivers/uio/uio_pci_generic.ko.xz
sudo cp /home/diamanti/dss_aws_ami/diamanti-node-prep.sh /var/lib/cloud/scripts/per-instance/

```

### Install nvme-cli pkg

```bash

dnf install -y nvme-cli

```
