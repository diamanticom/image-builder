#!/bin/bash

# Sets up the machineid when a new instance is initialized

# remove the existing machine-id
rm /etc/machine-id

#generate a new one
systemd-machine-id-setup

# setup the zone
echo "Setting Zone config"

echo "NAME=`curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone`" > /etc/diamanti/zone.conf
